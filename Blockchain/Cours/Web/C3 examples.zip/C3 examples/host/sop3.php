<?php 
setcookie("domaincookie","value"); 
?>
<html>
<head>
</head>
<iframe src="http://localhost:8000/setcookie"> </iframe>
<script>
</script>
</html>

